#!/bin/bash
echo "Reiniciando ovpn...";
/etc/init.d/openvpn restart;

