#!/bin/bash
clear
usuario=$1
[[ ! -e /bin/versao ]] && rm -rf /bin/menu
if [[ -e "/etc/SSHPlus/senha/$usuario" ]]; then
    senha=$(cat /etc/SSHPlus/senha/$usuario)
else
    senha="Null"
fi
datauser=$(chage -l $usuario |grep -i co |awk -F : '{print $2}')
if [ $datauser = never ] 2> /dev/null
then
data="\033[1;33mNunca\033[0m"
else
    databr="$(date -d "$datauser" +"%Y%m%d")"
    hoje="$(date -d today +"%Y%m%d")"
    if [ $hoje -ge $databr ]
    then
    data="\033[1;31mVenceu\033[0m"
    else
    dat="$(date -d"$datauser" '+%Y-%m-%d')"
    data=$(echo -e "$((($(date -ud $dat +%s)-$(date -ud $(date +%Y-%m-%d) +%s))/86400))")
    fi
fi
Data=$(printf '%-1s' "$data")
echo -e "$Data"

