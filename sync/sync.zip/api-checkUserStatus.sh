#!/bin/bash
token=$1;
totalUsuarios=$(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody | wc -l)
usuario_existe=$(grep $token /etc/passwd)
if [ -z "$usuario_existe" ]
then
   echo $totalUsuarios
else
   datauser=$(chage -l $token |grep -i co |awk -F : '{print $2}')
   dat="$(date -d"$datauser" '+%Y-%m-%d')"
   data=$(echo -e "$((($(date -ud $dat +%s)-$(date -ud $(date +%Y-%m-%d) +%s))/86400))")
   Data=$(printf "$data")
   echo "Renew user:"$Data;
fi

