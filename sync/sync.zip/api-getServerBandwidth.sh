#!/bin/bash
clear
echo -e "{"
#uptime
uptime="$(uptime -p)";
getUptime="${uptime/up /""}" 

getTrafegoSaida="${trafego_saida/)/""}"  

#trafego total de saida
print_trafego_saida="$(ifconfig eth0 | grep 'TX packets')";
trafego_saida="$(cut -d "(" -f2 <<< "$print_trafego_saida")";

getTrafegoSaida="${trafego_saida/)/""}"  
#uso atual da rede
old="$(</sys/class/net/eth0/statistics/tx_bytes)"; 
while $(sleep 1); do 
    now=$(</sys/class/net/eth0/statistics/tx_bytes);
    usage=$((($now-$old)/131072));
    old=$now; 
    echo -e "\"Uptime\": \"$getUptime\",";
    echo -e "\"OutputUsage\": \"$getTrafegoSaida\",";
    echo -e "\"LinkUsage\": \"$usage Mb/s\"";
    echo -e "}";
    break
done
  
